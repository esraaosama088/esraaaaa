import { postModel } from "../../../db/modules/post.model.js"





let getposts=async(req,res)=>{
    const posts = await postModel.find({})
    res.json({message:"all posts",posts})
}


let sendpost =async(req,res)=>{
    const addPost =await postModel.insertMany(req.body)
    res.json({message:"added successfully ",post:addPost})
}


let updatepost=async(req,res)=>{
    const updatepost=await postModel.findByIdAndUpdate(req.params.id,{...req.body},{returnDocument:'after'})
    res.json({message:"update doneee",updatepost})
}


let deletepost=async(req,res)=>{
    const deletepost= await postModel.findByIdAndUpdate(req.params.id)
    res.json({message:"post deleted successful",deletepost})
}


export{
    getposts,
    sendpost,
    updatepost
    ,deletepost
}