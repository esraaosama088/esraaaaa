
import express from 'express'
import { deletepost, getposts, sendpost, updatepost } from './post.controller.js'


export const postRouters=express.Router()

postRouters.use(express.json())

postRouters.get('/post',getposts )

postRouters.post('/post',express.json(),sendpost)

postRouters.put('/post/:id',express.json(),updatepost)


postRouters.delete('/post/:id',deletepost)

