
import express from 'express'
import { deleteuser, getALLusers, login, signup, updateusers } from './user.controller.js'

export const userRouters=express.Router()

userRouters.use(express.json())



userRouters.get('/user',getALLusers )
userRouters.post('/user/login',login)

userRouters.post('/user',express.json(),signup)
userRouters.put('/user/:id',express.json(),updateusers)

userRouters.delete('/user/:id',deleteuser)

