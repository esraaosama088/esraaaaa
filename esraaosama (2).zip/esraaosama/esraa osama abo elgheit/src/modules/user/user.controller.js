import { userModel } from "../../../db/modules/user.model.js"
import bcrypt from 'bcrypt';


let getALLusers =async(req,res)=>{
    const users = await userModel.find({})
    res.json({message:"all user",users})
}



let signup =async(req,res)=>{
const check =await userModel.findOne({email:req.body.email})
if(check){
    res.json({message:"user already register - go to login sir"})

}else{
    const hashed =bcrypt.hashSync(req.body.password,8)
  req.body.password=hashed
  const addedUser=await userModel.insertMany(req.body)
  addedUser[0].password=undefined
res.json({message:"added successful",addedUser})
}
}


let login = async (req, res) => {
  const founduser = await userModel.findOne({ email: req.body.email });
  if (!founduser) return res.json({ message: "user not found plz signup" });
  const match = bcrypt.compareSync(req.body.password, founduser.password);
  if (!match) return res.json({ message: "password or email not true" });
  res.json({ message: `welcome ${founduser.username}` });

}

let updateusers=async(req,res)=>{
    const check=await userModel.findOne({_id:req.params.id})
    if(!check)
        return res.json({message:"user this email not found"})
    
    const updateUser =await userModel.findOneAndUpdate({_id:req.params.id},{...req.body},{returnDocument:'after'})
    res.json({message:"updated successfullyyyyy ",updateUser})
}

let deleteuser=async(req,res)=>{
    const deleteUser= await userModel.findByIdAndUpdate(req.params.id)
    res.json({message:"user deleted successful",deleteUser})
}

export{
    getALLusers,
    signup,
    updateusers
    ,deleteuser,login
}