import express from 'express';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';

const router = express.Router();

router.post('/signup', async (req, res, next) => {
  try {
    const user = new User(req.body);
    await user.save();
    res.status(201).json({ message: 'User registered. Please confirm account manually.' });
  } catch (err) {
    next(err);
  }
});

router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !(await user.comparePassword(password))) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    if (!user.isConfirmed) {
      return res.status(403).json({ error: 'Please confirm your account first' });
    }
    const token = jwt.sign({ id: user._id, role: user.role }, 'secret');
    res.json({ token });
  } catch (err) {
    next(err);
  }
});

export default router;